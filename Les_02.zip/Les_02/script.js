"use strict";//строгий режим ;)

let out = document.getElementById("out");
let year = 1988;
out.innerHTML = 2019 - year;
alert("Andrew");
//Выводим код
console.log("let a = 'Hello'; let b = ' '; let c = 'world'; console.log(a+b+c); console.log(c+a+b);");
//Выполняем код(может, нужно ;) )
let a = 'Hello';
let b = ' ';
let c = 'world';
console.log(a + b + c);
console.log(c + a + b);